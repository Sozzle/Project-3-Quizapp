package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import static android.widget.Toast.LENGTH_LONG;
import static com.example.android.quizapp.R.id.checkbox_brussels;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private int totalScore = 0;
    private int scoreYesRadioButton = 0;
    private int scoreSecondYesRadioButton = 0;
    private int scoreThirdYesRadioButton = 0;
    private int scoreFourthYesRadioButton = 0;
    private int scoreFifthYesRadioButton = 0;
    private int scoreSixthYesRadioButton = 0;
    private int scoreNoRadioButton =0;
    private int scoreSecondNoRadioButton = 0;
    private int scoreThirdNoRadioButton = 0;
    private int scoreFourthNoRadioButton = 0;
    private int scoreFifthNoRadioButton = 0;
    private int scoreSixthNoRadioButton = 0;

    public void onRadioButtonClicked (View view) {
        boolean checked = ((RadioButton) view).isChecked();
        scoreYesRadioButton = 0;
        scoreSecondYesRadioButton = 0;
        scoreThirdYesRadioButton = 0;
        scoreFourthYesRadioButton = 0;
        scoreFifthYesRadioButton = 0;
        scoreSixthYesRadioButton = 0;
        scoreNoRadioButton = 0;
        scoreSecondNoRadioButton = 0;
        scoreThirdNoRadioButton = 0;
        scoreFourthNoRadioButton = 0;
        scoreFifthNoRadioButton = 0;
        scoreSixthNoRadioButton = 0;
    }

    public void onCheckboxClicked (View view) {
        //Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();
        //Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.checkbox_vienna:
                if (checked)
                    totalScore = totalScore +1;
                break;
            case checkbox_brussels:
                if (checked)
                    totalScore = 0;
                break;
        }}

    public void SubmitScore (View view) {
        RadioButton yesRadioButton = findViewById(R.id.yes_radio_button);
        //Is the button  now checked?
        if (yesRadioButton.isChecked()) {
            scoreYesRadioButton = scoreYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton secondYesRadioButton = findViewById(R.id.second_yes_radio_button);
        //Is the button  now checked?
        if (secondYesRadioButton.isChecked()) {
            scoreSecondYesRadioButton = scoreSecondYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton thirdYesRadioButton = findViewById(R.id.third_yes_radio_button);
        //Is the button  now checked?
        if (thirdYesRadioButton.isChecked()) {
            scoreThirdYesRadioButton = scoreThirdYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton fourthYesRadioButton = findViewById(R.id.fourth_yes_radio_button);
        //Is the button  now checked?
        if (fourthYesRadioButton.isChecked()) {
            scoreFourthYesRadioButton = scoreFourthYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton fifthYesRadioButton = findViewById(R.id.fifth_yes_radio_button);
        //Is the button  now checked?
        if (fifthYesRadioButton.isChecked()) {
            scoreFifthYesRadioButton = scoreFifthYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton sixthYesRadioButton = findViewById(R.id.sixth_yes_radio_button);
        //Is the button now checked?
        if (sixthYesRadioButton.isChecked()) {
            scoreSixthYesRadioButton = scoreSixthYesRadioButton + 1;
            totalScore = totalScore + 1;
        }

        RadioButton noRadioButton = findViewById(R.id.no_radio_button);
        {
            scoreNoRadioButton = 0;

        }

        RadioButton secondNoRadioButton = findViewById(R.id.second_no_radio_button);
        {
            scoreSecondNoRadioButton = 0;

        }

        RadioButton thirdNoRadioButton = findViewById(R.id.third_no_radio_button);
        {
            scoreThirdNoRadioButton = 0;

        }
        RadioButton fourthNoRadioButton = findViewById(R.id.fourth_no_radio_button);
        {
            scoreFourthNoRadioButton = 0;
        }

        RadioButton fifthNoRadioButton = findViewById(R.id.fifth_no_radio_button);
        {
            scoreFifthNoRadioButton = 0;
        }

        RadioButton sixthNoRadioButton = findViewById(R.id.sixth_no_radio_button);
        {
            scoreSixthNoRadioButton = 0;
        }


        EditText answerField = (EditText) findViewById(R.id.answer_field);
        String name = answerField.getText().toString();
        //Correct answer is Canberra
        totalScore = totalScore + 1;
        //Incorrect answer
        totalScore = 0;


        {
            CheckBox Vienna = (CheckBox) findViewById(R.id.checkbox_vienna);
            boolean Vienna_CheckBox = Vienna.isChecked();
            totalScore = totalScore + 1;
            //Correct answer//
        }

        {
            CheckBox Brussels = (CheckBox) findViewById(checkbox_brussels);
            boolean Brussels_CheckBox = Brussels.isChecked();
            totalScore = 0;

        }

        { //The above adds up the scores and returns total score//
            //Q1 Capital City of England is London is correct so Yes button is clicked//
            //Q2 question Capital City of Scotland is Edinburgh is correct so Yes button is clicked//
            //Q3 Capital City of France is Paris is correct so Yes button is clicked//
            //Q4 Capital City of Germany is Berlin is correct so Yes button is clicked//
            //Q5 Capital City of Greece is Athens is correct so Yes button is clicked//
            //Q6 Capital City of Portugal is Lisbon is correct so Yes button is clicked??
            //Q7 What is the capital city of Australia EditText correct answer is Canberra and will be given a score of +1//
            //Q8 What is the capital city of Austria correct answer is Vienna and will be given a score of + 1//
            // Yes is the correct answer and will be given a score of +1//
            //No is the incorrect answer and will not be give a score//
            // Depending on the correct or incorrect answers, one of the toasts is shown below//
            //total correct answers is 8//
        }
        if (totalScore != 8) {
            //Show a congratulations message
            Toast.makeText(this, "Congratulations, you have 8 correct answsers", LENGTH_LONG).show();
        }
            else

        if (totalScore <= 8) {
            //Show a sorry message
            Toast.makeText(this, "Sorry try again", Toast.LENGTH_SHORT).show();
        }
        {
            //Reset total score of quiz to be 0 after showing toast message
            totalScore = 0;
        }

    }}

















